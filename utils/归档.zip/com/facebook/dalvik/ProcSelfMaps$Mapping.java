package com.facebook.dalvik;

public class ProcSelfMaps$Mapping
{
  private final long a;
  private final long b;
  private final boolean c;
  private final boolean d;
  private final boolean e;
  private final String f;

  ProcSelfMaps$Mapping(long paramLong1, long paramLong2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString)
  {
    this.a = paramLong1;
    this.b = paramLong2;
    this.c = paramBoolean1;
    this.d = paramBoolean2;
    this.e = paramBoolean3;
    this.f = paramString;
  }

  public long a()
  {
    return this.a;
  }

  public long b()
  {
    return this.b;
  }

  public boolean c()
  {
    return this.c;
  }

  public String d()
  {
    return this.f;
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.dalvik.ProcSelfMaps.Mapping
 * JD-Core Version:    0.6.2
 */