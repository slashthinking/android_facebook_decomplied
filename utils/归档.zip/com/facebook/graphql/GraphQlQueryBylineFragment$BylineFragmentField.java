package com.facebook.graphql;

public final class GraphQlQueryBylineFragment$BylineFragmentField extends GraphQlQueryBaseObjectImpl.FieldImpl
{
  GraphQlQueryBylineFragment$BylineFragmentField(String paramString)
  {
    super("BylineFragment", paramString);
  }

  GraphQlQueryBylineFragment$BylineFragmentField(String paramString, GraphQlQueryBaseObject paramGraphQlQueryBaseObject)
  {
    super("BylineFragment", paramString, null, paramGraphQlQueryBaseObject);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryBylineFragment.BylineFragmentField
 * JD-Core Version:    0.6.2
 */