package com.facebook.graphql;

import java.util.List;

public class GraphQl$Node
{
  public static final GraphQlQueryNodeImpl.NodeGenericField a = new GraphQlQueryNodeImpl.NodeGenericField("id");
  public static final GraphQlQueryNodeImpl.NodeGenericField b = new GraphQlQueryNodeImpl.NodeGenericField("url.site(mobile)");

  public static GraphQlQueryNodeImpl a(List<? extends GraphQlQueryFieldNode> paramList)
  {
    return new GraphQlQueryNodeImpl(paramList, null);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQl.Node
 * JD-Core Version:    0.6.2
 */