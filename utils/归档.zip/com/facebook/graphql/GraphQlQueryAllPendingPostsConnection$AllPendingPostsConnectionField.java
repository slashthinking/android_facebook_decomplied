package com.facebook.graphql;

public final class GraphQlQueryAllPendingPostsConnection$AllPendingPostsConnectionField extends GraphQlQueryBaseObjectImpl.FieldImpl
{
  GraphQlQueryAllPendingPostsConnection$AllPendingPostsConnectionField(String paramString)
  {
    super("AllPendingPostsConnection", paramString);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryAllPendingPostsConnection.AllPendingPostsConnectionField
 * JD-Core Version:    0.6.2
 */