package com.facebook.graphql;

public final class GraphQlQueryCelebrationsFeedUnit$CelebrationsFeedUnitField extends GraphQlQueryBaseObjectImpl.FieldImpl
  implements GraphQlQueryFieldItemListFeedUnit
{
  GraphQlQueryCelebrationsFeedUnit$CelebrationsFeedUnitField(String paramString)
  {
    super("CelebrationsFeedUnit", paramString);
  }

  GraphQlQueryCelebrationsFeedUnit$CelebrationsFeedUnitField(String paramString, GraphQlQueryBaseObject paramGraphQlQueryBaseObject)
  {
    super("CelebrationsFeedUnit", paramString, null, paramGraphQlQueryBaseObject);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryCelebrationsFeedUnit.CelebrationsFeedUnitField
 * JD-Core Version:    0.6.2
 */