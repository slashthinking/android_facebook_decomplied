package com.facebook.graphql;

public final class GraphQlQueryCallScale1 extends GraphQlQueryBaseFieldCallImpl
  implements GraphQlQueryIcon.CallOnIcon
{
  GraphQlQueryCallScale1(String paramString)
  {
    super("scale", new String[] { paramString });
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryCallScale1
 * JD-Core Version:    0.6.2
 */