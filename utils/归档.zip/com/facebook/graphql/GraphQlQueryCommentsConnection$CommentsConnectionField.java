package com.facebook.graphql;

public final class GraphQlQueryCommentsConnection$CommentsConnectionField extends GraphQlQueryBaseObjectImpl.FieldImpl
{
  GraphQlQueryCommentsConnection$CommentsConnectionField(String paramString)
  {
    super("CommentsConnection", paramString);
  }

  GraphQlQueryCommentsConnection$CommentsConnectionField(String paramString, GraphQlQueryBaseObject paramGraphQlQueryBaseObject)
  {
    super("CommentsConnection", paramString, null, paramGraphQlQueryBaseObject);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryCommentsConnection.CommentsConnectionField
 * JD-Core Version:    0.6.2
 */