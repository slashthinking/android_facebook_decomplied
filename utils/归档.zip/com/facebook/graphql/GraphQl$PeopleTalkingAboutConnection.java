package com.facebook.graphql;

import com.google.common.collect.ImmutableList;

public class GraphQl$PeopleTalkingAboutConnection
{
  public static final GraphQlQueryPeopleTalkingAboutConnection.PeopleTalkingAboutConnectionField a = new GraphQlQueryPeopleTalkingAboutConnection.PeopleTalkingAboutConnectionField("count");

  public static GraphQlQueryPeopleTalkingAboutConnection a(GraphQlQueryPeopleTalkingAboutConnection.PeopleTalkingAboutConnectionField[] paramArrayOfPeopleTalkingAboutConnectionField)
  {
    return new GraphQlQueryPeopleTalkingAboutConnection(null, ImmutableList.a(paramArrayOfPeopleTalkingAboutConnectionField), null);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQl.PeopleTalkingAboutConnection
 * JD-Core Version:    0.6.2
 */