package com.facebook.graphql;

import java.util.List;

public final class GraphQlQueryAllPendingPostsConnection extends GraphQlQueryBaseCallable
{
  GraphQlQueryAllPendingPostsConnection(List<? extends GraphQlQueryBaseFieldCall> paramList, List<? extends GraphQlQueryBaseField> paramList1, String paramString)
  {
    super(paramList, paramList1, paramString, false);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryAllPendingPostsConnection
 * JD-Core Version:    0.6.2
 */