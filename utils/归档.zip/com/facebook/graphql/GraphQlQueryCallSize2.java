package com.facebook.graphql;

public final class GraphQlQueryCallSize2 extends GraphQlQueryBaseFieldCallImpl
  implements GraphQlQueryImage.CallOnImage
{
  GraphQlQueryCallSize2(long paramLong1, long paramLong2)
  {
    super("size", arrayOfString);
  }

  GraphQlQueryCallSize2(GraphQlQueryParam paramGraphQlQueryParam1, GraphQlQueryParam paramGraphQlQueryParam2)
  {
    super("size", new GraphQlQueryParam[] { paramGraphQlQueryParam1, paramGraphQlQueryParam2 });
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryCallSize2
 * JD-Core Version:    0.6.2
 */