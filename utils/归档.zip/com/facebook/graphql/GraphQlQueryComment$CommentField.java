package com.facebook.graphql;

public final class GraphQlQueryComment$CommentField extends GraphQlQueryBaseObjectImpl.FieldImpl
  implements GraphQlQueryFieldEntity, GraphQlQueryFieldNode
{
  GraphQlQueryComment$CommentField(String paramString)
  {
    super("Comment", paramString);
  }

  GraphQlQueryComment$CommentField(String paramString, GraphQlQueryBaseObject paramGraphQlQueryBaseObject)
  {
    super("Comment", paramString, null, paramGraphQlQueryBaseObject);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryComment.CommentField
 * JD-Core Version:    0.6.2
 */