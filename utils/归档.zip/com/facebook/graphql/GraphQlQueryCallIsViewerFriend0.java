package com.facebook.graphql;

public final class GraphQlQueryCallIsViewerFriend0 extends GraphQlQueryBaseFieldCallImpl
  implements GraphQlQueryPageStarRatersConnection.CallOnPageStarRatersConnection
{
  GraphQlQueryCallIsViewerFriend0()
  {
    super("is_viewer_friend", null, null);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryCallIsViewerFriend0
 * JD-Core Version:    0.6.2
 */