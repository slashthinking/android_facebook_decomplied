package com.facebook.graphql;

public final class GraphQlQueryAppCenterCategoryItem$AppCenterCategoryItemField extends GraphQlQueryBaseObjectImpl.FieldImpl
{
  GraphQlQueryAppCenterCategoryItem$AppCenterCategoryItemField(String paramString)
  {
    super("AppCenterCategoryItem", paramString);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryAppCenterCategoryItem.AppCenterCategoryItemField
 * JD-Core Version:    0.6.2
 */