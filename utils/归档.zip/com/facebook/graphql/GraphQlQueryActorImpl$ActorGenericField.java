package com.facebook.graphql;

public final class GraphQlQueryActorImpl$ActorGenericField extends GraphQlQueryBaseObjectImpl.FieldImpl
  implements GraphQlQueryFieldActor
{
  GraphQlQueryActorImpl$ActorGenericField(String paramString)
  {
    super("Actor", paramString);
  }

  GraphQlQueryActorImpl$ActorGenericField(String paramString, GraphQlQueryBaseObject paramGraphQlQueryBaseObject)
  {
    super("Actor", paramString, null, paramGraphQlQueryBaseObject);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryActorImpl.ActorGenericField
 * JD-Core Version:    0.6.2
 */