package com.facebook.graphql;

import com.google.common.collect.ImmutableList;

public class GraphQl$ViewerVisitsConnection
{
  public static final GraphQlQueryViewerVisitsConnection.ViewerVisitsConnectionField a = new GraphQlQueryViewerVisitsConnection.ViewerVisitsConnectionField("count");

  public static GraphQlQueryViewerVisitsConnection a(GraphQlQueryViewerVisitsConnection.ViewerVisitsConnectionField[] paramArrayOfViewerVisitsConnectionField)
  {
    return new GraphQlQueryViewerVisitsConnection(null, ImmutableList.a(paramArrayOfViewerVisitsConnectionField), null);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQl.ViewerVisitsConnection
 * JD-Core Version:    0.6.2
 */