package com.facebook.graphql;

import com.google.common.collect.ImmutableList;

public class GraphQl$Entity
{
  public static final GraphQlQueryEntityImpl.EntityGenericField a = new GraphQlQueryEntityImpl.EntityGenericField("url.site(mobile)");

  public static GraphQlQueryEntityImpl a(GraphQlQueryFieldEntity[] paramArrayOfGraphQlQueryFieldEntity)
  {
    return new GraphQlQueryEntityImpl(ImmutableList.a(paramArrayOfGraphQlQueryFieldEntity), null);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQl.Entity
 * JD-Core Version:    0.6.2
 */