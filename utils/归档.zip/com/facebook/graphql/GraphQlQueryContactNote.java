package com.facebook.graphql;

public abstract interface GraphQlQueryContactNote extends GraphQlQueryBaseObject
{
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryContactNote
 * JD-Core Version:    0.6.2
 */