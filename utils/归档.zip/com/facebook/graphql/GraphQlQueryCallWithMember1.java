package com.facebook.graphql;

public final class GraphQlQueryCallWithMember1 extends GraphQlQueryBaseFieldCallImpl
  implements GraphQlQueryFriendListsConnection.CallOnFriendListsConnection
{
  GraphQlQueryCallWithMember1(GraphQlQueryParam paramGraphQlQueryParam)
  {
    super("with_member", new GraphQlQueryParam[] { paramGraphQlQueryParam });
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryCallWithMember1
 * JD-Core Version:    0.6.2
 */