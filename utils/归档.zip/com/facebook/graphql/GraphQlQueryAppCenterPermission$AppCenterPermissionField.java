package com.facebook.graphql;

public final class GraphQlQueryAppCenterPermission$AppCenterPermissionField extends GraphQlQueryBaseObjectImpl.FieldImpl
{
  GraphQlQueryAppCenterPermission$AppCenterPermissionField(String paramString)
  {
    super("AppCenterPermission", paramString);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryAppCenterPermission.AppCenterPermissionField
 * JD-Core Version:    0.6.2
 */