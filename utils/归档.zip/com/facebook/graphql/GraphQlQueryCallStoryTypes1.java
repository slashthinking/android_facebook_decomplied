package com.facebook.graphql;

public final class GraphQlQueryCallStoryTypes1 extends GraphQlQueryBaseFieldCallImpl
  implements GraphQlQueryHomeStoriesConnection.CallOnHomeStoriesConnection, GraphQlQueryNewsFeedConnection.CallOnNewsFeedConnection, GraphQlQuerySectionFeedConnection.CallOnSectionFeedConnection
{
  GraphQlQueryCallStoryTypes1(GraphQlQueryParam paramGraphQlQueryParam)
  {
    super("story_types", new GraphQlQueryParam[] { paramGraphQlQueryParam });
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryCallStoryTypes1
 * JD-Core Version:    0.6.2
 */