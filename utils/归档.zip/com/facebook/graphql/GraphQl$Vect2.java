package com.facebook.graphql;

import com.google.common.collect.ImmutableList;

public class GraphQl$Vect2
{
  public static final GraphQlQueryVect2.Vect2Field a = new GraphQlQueryVect2.Vect2Field("x");
  public static final GraphQlQueryVect2.Vect2Field b = new GraphQlQueryVect2.Vect2Field("y");

  public static GraphQlQueryVect2 a(GraphQlQueryVect2.Vect2Field[] paramArrayOfVect2Field)
  {
    return new GraphQlQueryVect2(ImmutableList.a(paramArrayOfVect2Field), null);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQl.Vect2
 * JD-Core Version:    0.6.2
 */