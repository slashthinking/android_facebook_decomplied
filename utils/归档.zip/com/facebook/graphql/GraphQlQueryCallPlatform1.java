package com.facebook.graphql;

public final class GraphQlQueryCallPlatform1 extends GraphQlQueryBaseFieldCallImpl
  implements GraphQlQueryRecommendedApplicationsConnection.CallOnRecommendedApplicationsConnection
{
  GraphQlQueryCallPlatform1(String paramString)
  {
    super("platform", new String[] { paramString });
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryCallPlatform1
 * JD-Core Version:    0.6.2
 */