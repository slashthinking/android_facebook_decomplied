package com.facebook.graphql;

import com.google.common.collect.ImmutableList;

public class GraphQl$SubscribersConnection
{
  public static final GraphQlQuerySubscribersConnection.SubscribersConnectionField a = new GraphQlQuerySubscribersConnection.SubscribersConnectionField("count");

  public static GraphQlQuerySubscribersConnection a(GraphQlQuerySubscribersConnection.SubscribersConnectionField[] paramArrayOfSubscribersConnectionField)
  {
    return new GraphQlQuerySubscribersConnection(null, ImmutableList.a(paramArrayOfSubscribersConnectionField), null);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQl.SubscribersConnection
 * JD-Core Version:    0.6.2
 */