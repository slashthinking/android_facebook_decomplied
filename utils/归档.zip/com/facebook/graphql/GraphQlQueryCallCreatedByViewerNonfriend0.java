package com.facebook.graphql;

public final class GraphQlQueryCallCreatedByViewerNonfriend0 extends GraphQlQueryBaseFieldCallImpl
  implements GraphQlQueryContactSectionNotesConnection.CallOnContactSectionNotesConnection, GraphQlQueryPageRecommendationsConnection.CallOnPageRecommendationsConnection
{
  GraphQlQueryCallCreatedByViewerNonfriend0()
  {
    super("created_by_viewer_nonfriend", null, null);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryCallCreatedByViewerNonfriend0
 * JD-Core Version:    0.6.2
 */