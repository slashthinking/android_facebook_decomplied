package com.facebook.graphql;

public final class GraphQlQueryAppCenter$AppCenterField extends GraphQlQueryBaseObjectImpl.FieldImpl
  implements GraphQlQueryFieldEntity, GraphQlQueryFieldNode
{
  GraphQlQueryAppCenter$AppCenterField(String paramString)
  {
    super("AppCenter", paramString);
  }

  GraphQlQueryAppCenter$AppCenterField(String paramString, GraphQlQueryBaseObject paramGraphQlQueryBaseObject)
  {
    super("AppCenter", paramString, null, paramGraphQlQueryBaseObject);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryAppCenter.AppCenterField
 * JD-Core Version:    0.6.2
 */