package com.facebook.graphql;

public final class GraphQlQueryAggregatedEntitiesAtRange$AggregatedEntitiesAtRangeField extends GraphQlQueryBaseObjectImpl.FieldImpl
{
  GraphQlQueryAggregatedEntitiesAtRange$AggregatedEntitiesAtRangeField(String paramString)
  {
    super("AggregatedEntitiesAtRange", paramString);
  }

  GraphQlQueryAggregatedEntitiesAtRange$AggregatedEntitiesAtRangeField(String paramString, GraphQlQueryBaseObject paramGraphQlQueryBaseObject)
  {
    super("AggregatedEntitiesAtRange", paramString, null, paramGraphQlQueryBaseObject);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryAggregatedEntitiesAtRange.AggregatedEntitiesAtRangeField
 * JD-Core Version:    0.6.2
 */