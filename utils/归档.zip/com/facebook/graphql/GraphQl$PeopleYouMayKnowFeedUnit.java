package com.facebook.graphql;

public class GraphQl$PeopleYouMayKnowFeedUnit
{
  public static final GraphQlQueryPeopleYouMayKnowFeedUnit.PeopleYouMayKnowFeedUnitField a = new GraphQlQueryPeopleYouMayKnowFeedUnit.PeopleYouMayKnowFeedUnitField("debug_info");
  public static final GraphQlQueryPeopleYouMayKnowFeedUnit.PeopleYouMayKnowFeedUnitField b = new GraphQlQueryPeopleYouMayKnowFeedUnit.PeopleYouMayKnowFeedUnitField("cache_id");

  public static GraphQlQueryPeopleYouMayKnowFeedUnit.PeopleYouMayKnowFeedUnitField a(GraphQlQueryPeopleYouMayKnowFeedUnitItem paramGraphQlQueryPeopleYouMayKnowFeedUnitItem)
  {
    return new GraphQlQueryPeopleYouMayKnowFeedUnit.PeopleYouMayKnowFeedUnitField("items", paramGraphQlQueryPeopleYouMayKnowFeedUnitItem);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQl.PeopleYouMayKnowFeedUnit
 * JD-Core Version:    0.6.2
 */