package com.facebook.graphql;

public abstract interface GraphQlQueryBaseField extends GraphQlQueryBaseType
{
  public abstract GraphQlQueryBaseObject a();

  public abstract String b();

  public abstract String c();
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.graphql.GraphQlQueryBaseField
 * JD-Core Version:    0.6.2
 */