package com.facebook.bookmark.ui;

import android.view.View;
import android.widget.TextView;

public class BaseViewItemFactory$TextLabelViewHolder
{
  public final TextView e;

  public BaseViewItemFactory$TextLabelViewHolder(View paramView)
  {
    this.e = ((TextView)paramView.findViewById(2131296409));
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.bookmark.ui.BaseViewItemFactory.TextLabelViewHolder
 * JD-Core Version:    0.6.2
 */