package com.facebook.bookmark.ui;

import android.view.View;
import android.widget.TextView;

public class BaseViewItemFactory$BookmarkViewHolder extends BaseViewItemFactory.BaseBookmarkViewHolder
{
  public final TextView c;

  public BaseViewItemFactory$BookmarkViewHolder(View paramView)
  {
    super(paramView);
    this.c = ((TextView)paramView.findViewById(2131296414));
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.bookmark.ui.BaseViewItemFactory.BookmarkViewHolder
 * JD-Core Version:    0.6.2
 */