package com.facebook.bookmark.ui;

public class BaseBookmarkMenuFragment$ScrollState
{
  public final int a;
  public final int b;

  private BaseBookmarkMenuFragment$ScrollState(int paramInt1, int paramInt2)
  {
    this.a = paramInt1;
    this.b = paramInt2;
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.bookmark.ui.BaseBookmarkMenuFragment.ScrollState
 * JD-Core Version:    0.6.2
 */