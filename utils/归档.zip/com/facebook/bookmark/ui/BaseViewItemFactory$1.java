package com.facebook.bookmark.ui;

import java.util.HashMap;

final class BaseViewItemFactory$1 extends HashMap<String, Integer>
{
  BaseViewItemFactory$1()
  {
    put("group.png", Integer.valueOf(2130838286));
    put("photo.gif", Integer.valueOf(2130838173));
    put("messages.png", Integer.valueOf(2130838169));
    put("event.gif", Integer.valueOf(2130838166));
    put("friends.png", Integer.valueOf(2130838167));
    put("place.png", Integer.valueOf(2130838170));
    put("note.gif", Integer.valueOf(2130838172));
    put("newsfeed.png", Integer.valueOf(2130838171));
    put("account.png", Integer.valueOf(2130837504));
    put("editbookmarks.png", Integer.valueOf(2130837582));
    put("friend_guy.png", Integer.valueOf(2130838269));
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.bookmark.ui.BaseViewItemFactory.1
 * JD-Core Version:    0.6.2
 */