package com.facebook.bookmark.ui;

import android.view.View;
import android.widget.RelativeLayout;

public class BaseViewItemFactory$BaseBookmarkViewHolder extends BaseViewItemFactory.IconLabelViewHolder
{
  public final RelativeLayout a;
  public final View b;

  public BaseViewItemFactory$BaseBookmarkViewHolder(View paramView)
  {
    super(paramView);
    this.b = paramView.findViewById(2131296411);
    this.a = ((RelativeLayout)paramView.findViewById(2131296410));
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.bookmark.ui.BaseViewItemFactory.BaseBookmarkViewHolder
 * JD-Core Version:    0.6.2
 */