package com.facebook.bookmark.ui;

import android.view.View;
import com.facebook.widget.UrlImage;

public class BaseViewItemFactory$IconLabelViewHolder extends BaseViewItemFactory.TextLabelViewHolder
{
  public final UrlImage d;

  public BaseViewItemFactory$IconLabelViewHolder(View paramView)
  {
    super(paramView);
    this.d = ((UrlImage)paramView.findViewById(2131296413));
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.bookmark.ui.BaseViewItemFactory.IconLabelViewHolder
 * JD-Core Version:    0.6.2
 */