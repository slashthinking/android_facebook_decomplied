package com.facebook.bookmark.ui;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class BaseViewItemFactory$ProfileViewHolder extends BaseViewItemFactory.IconLabelViewHolder
{
  public final ImageView a;
  public final RelativeLayout b;

  public BaseViewItemFactory$ProfileViewHolder(View paramView)
  {
    super(paramView);
    this.a = ((ImageView)paramView.findViewById(2131296416));
    this.b = ((RelativeLayout)paramView.findViewById(2131296410));
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.bookmark.ui.BaseViewItemFactory.ProfileViewHolder
 * JD-Core Version:    0.6.2
 */