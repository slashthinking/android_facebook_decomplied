package com.facebook.bookmark.service;

class BookmarkServiceModule$1
{
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.bookmark.service.BookmarkServiceModule.1
 * JD-Core Version:    0.6.2
 */