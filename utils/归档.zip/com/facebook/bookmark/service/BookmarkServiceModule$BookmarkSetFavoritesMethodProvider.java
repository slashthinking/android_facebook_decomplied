package com.facebook.bookmark.service;

import com.facebook.bookmark.protocol.BookmarkSetFavoritesMethod;
import com.facebook.orca.inject.AbstractProvider;

class BookmarkServiceModule$BookmarkSetFavoritesMethodProvider extends AbstractProvider<BookmarkSetFavoritesMethod>
{
  private BookmarkServiceModule$BookmarkSetFavoritesMethodProvider(BookmarkServiceModule paramBookmarkServiceModule)
  {
  }

  public BookmarkSetFavoritesMethod a()
  {
    return new BookmarkSetFavoritesMethod();
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.bookmark.service.BookmarkServiceModule.BookmarkSetFavoritesMethodProvider
 * JD-Core Version:    0.6.2
 */