package com.facebook.bookmark.ipc;

import com.facebook.common.db.Table.Column;
import com.facebook.common.db.Table.ColumnType;

public final class GroupOrderTable$Columns
{
  public static final Table.Column a = new Table.Column("group_id", Table.ColumnType.TEXT, true);
  public static final Table.Column b = new Table.Column("group_order", Table.ColumnType.INTEGER);
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.bookmark.ipc.GroupOrderTable.Columns
 * JD-Core Version:    0.6.2
 */