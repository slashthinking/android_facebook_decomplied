package com.facebook.fragment;

import android.content.Intent;

class NavigableFragmentController$1
  implements NavigableFragment.Listener
{
  NavigableFragmentController$1(NavigableFragmentController paramNavigableFragmentController)
  {
  }

  public void a(NavigableFragment paramNavigableFragment, Intent paramIntent)
  {
    NavigableFragmentController.a(this.a, paramNavigableFragment, paramIntent);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.fragment.NavigableFragmentController.1
 * JD-Core Version:    0.6.2
 */