package com.facebook.fragment;

import android.content.Intent;

public abstract interface NavigableFragment$Listener
{
  public abstract void a(NavigableFragment paramNavigableFragment, Intent paramIntent);
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.fragment.NavigableFragment.Listener
 * JD-Core Version:    0.6.2
 */