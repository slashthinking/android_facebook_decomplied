package com.facebook.facedetection;

import android.graphics.Bitmap;
import java.util.List;

abstract interface Tracker$InternalFaceDetector
{
  public abstract List<Tracker.DetectionData> a(Bitmap paramBitmap, int paramInt, boolean paramBoolean);
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.facedetection.Tracker.InternalFaceDetector
 * JD-Core Version:    0.6.2
 */