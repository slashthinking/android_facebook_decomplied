package com.facebook.analytics;

import com.facebook.orca.ops.OrcaServiceOperation;
import com.facebook.orca.ops.OrcaServiceOperation.OnCompletedListener;
import com.facebook.orca.ops.ServiceException;
import com.facebook.orca.server.OperationResult;

class DefaultHoneyAnalyticsPeriodicReporter$1 extends OrcaServiceOperation.OnCompletedListener
{
  DefaultHoneyAnalyticsPeriodicReporter$1(DefaultHoneyAnalyticsPeriodicReporter paramDefaultHoneyAnalyticsPeriodicReporter, OrcaServiceOperation paramOrcaServiceOperation)
  {
  }

  public void a(ServiceException paramServiceException)
  {
    this.a.d();
  }

  public void a(OperationResult paramOperationResult)
  {
    this.a.d();
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.analytics.DefaultHoneyAnalyticsPeriodicReporter.1
 * JD-Core Version:    0.6.2
 */