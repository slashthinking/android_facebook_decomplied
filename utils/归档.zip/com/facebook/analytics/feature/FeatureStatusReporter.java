package com.facebook.analytics.feature;

public abstract interface FeatureStatusReporter
{
  public abstract String a();

  public abstract boolean b();
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.analytics.feature.FeatureStatusReporter
 * JD-Core Version:    0.6.2
 */