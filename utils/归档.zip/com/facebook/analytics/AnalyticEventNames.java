package com.facebook.analytics;

public class AnalyticEventNames
{
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.analytics.AnalyticEventNames
 * JD-Core Version:    0.6.2
 */