package com.facebook.analytics;

class AnalyticsLogger$2
  implements Runnable
{
  AnalyticsLogger$2(AnalyticsLogger paramAnalyticsLogger, long paramLong)
  {
  }

  public void run()
  {
    AnalyticsLogger.a(this.b, this.a);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.analytics.AnalyticsLogger.2
 * JD-Core Version:    0.6.2
 */