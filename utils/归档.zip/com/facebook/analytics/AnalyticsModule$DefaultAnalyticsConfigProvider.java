package com.facebook.analytics;

import com.facebook.orca.inject.AbstractProvider;

class AnalyticsModule$DefaultAnalyticsConfigProvider extends AbstractProvider<AnalyticsConfig>
{
  private AnalyticsModule$DefaultAnalyticsConfigProvider(AnalyticsModule paramAnalyticsModule)
  {
  }

  public AnalyticsConfig a()
  {
    return new AnalyticsModule.DefaultAnalyticsConfigProvider.1(this);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.analytics.AnalyticsModule.DefaultAnalyticsConfigProvider
 * JD-Core Version:    0.6.2
 */