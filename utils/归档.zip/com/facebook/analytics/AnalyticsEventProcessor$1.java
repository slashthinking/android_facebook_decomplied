package com.facebook.analytics;

class AnalyticsEventProcessor$1
  implements Runnable
{
  AnalyticsEventProcessor$1(AnalyticsEventProcessor paramAnalyticsEventProcessor)
  {
  }

  public void run()
  {
    AnalyticsEventProcessor.a(this.a);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.analytics.AnalyticsEventProcessor.1
 * JD-Core Version:    0.6.2
 */