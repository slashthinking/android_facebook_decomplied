package com.facebook.analytics;

class AnalyticsService$AnalyticsServiceStub extends IAnalyticsService.Stub
{
  private AnalyticsService$AnalyticsServiceStub(AnalyticsService paramAnalyticsService)
  {
  }

  public void a(AnalyticsServiceEvent paramAnalyticsServiceEvent)
  {
    AnalyticsService.a(this.a, paramAnalyticsServiceEvent);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.analytics.AnalyticsService.AnalyticsServiceStub
 * JD-Core Version:    0.6.2
 */