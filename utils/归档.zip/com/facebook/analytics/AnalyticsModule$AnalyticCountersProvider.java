package com.facebook.analytics;

import com.facebook.orca.inject.AbstractProvider;

class AnalyticsModule$AnalyticCountersProvider extends AbstractProvider<AnalyticCounters>
{
  private AnalyticsModule$AnalyticCountersProvider(AnalyticsModule paramAnalyticsModule)
  {
  }

  public AnalyticCounters a()
  {
    return new AnalyticCounters();
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.analytics.AnalyticsModule.AnalyticCountersProvider
 * JD-Core Version:    0.6.2
 */