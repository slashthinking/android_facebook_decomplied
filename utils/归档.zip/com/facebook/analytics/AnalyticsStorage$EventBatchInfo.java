package com.facebook.analytics;

public class AnalyticsStorage$EventBatchInfo
{
  public final String a;
  public final String b;
  public final long c;
  public final long d;
  public final String e;
  public final boolean f;

  public AnalyticsStorage$EventBatchInfo(AnalyticsStorage paramAnalyticsStorage, String paramString1, String paramString2, long paramLong1, String paramString3, long paramLong2, boolean paramBoolean)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramLong1;
    this.e = paramString3;
    this.f = paramBoolean;
    this.d = paramLong2;
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.analytics.AnalyticsStorage.EventBatchInfo
 * JD-Core Version:    0.6.2
 */