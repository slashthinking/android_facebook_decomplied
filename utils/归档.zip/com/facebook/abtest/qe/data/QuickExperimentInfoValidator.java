package com.facebook.abtest.qe.data;

public abstract interface QuickExperimentInfoValidator
{
  public abstract boolean a(QuickExperimentInfo paramQuickExperimentInfo);
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.abtest.qe.data.QuickExperimentInfoValidator
 * JD-Core Version:    0.6.2
 */