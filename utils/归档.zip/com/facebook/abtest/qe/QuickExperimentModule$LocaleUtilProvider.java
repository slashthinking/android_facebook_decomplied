package com.facebook.abtest.qe;

import com.facebook.abtest.qe.utils.LocaleUtil;
import com.facebook.orca.inject.AbstractProvider;

class QuickExperimentModule$LocaleUtilProvider extends AbstractProvider<LocaleUtil>
{
  private QuickExperimentModule$LocaleUtilProvider(QuickExperimentModule paramQuickExperimentModule)
  {
  }

  public LocaleUtil a()
  {
    return new LocaleUtil();
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.abtest.qe.QuickExperimentModule.LocaleUtilProvider
 * JD-Core Version:    0.6.2
 */