package com.facebook.abtest.qe.utils;

import java.util.Locale;

public class LocaleUtil
{
  public String a()
  {
    return Locale.getDefault().toString();
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.abtest.qe.utils.LocaleUtil
 * JD-Core Version:    0.6.2
 */