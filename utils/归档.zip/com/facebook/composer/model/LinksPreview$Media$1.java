package com.facebook.composer.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class LinksPreview$Media$1
  implements Parcelable.Creator<LinksPreview.Media>
{
  public LinksPreview.Media a(Parcel paramParcel)
  {
    return new LinksPreview.Media(paramParcel, null);
  }

  public LinksPreview.Media[] a(int paramInt)
  {
    return new LinksPreview.Media[paramInt];
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.model.LinksPreview.Media.1
 * JD-Core Version:    0.6.2
 */