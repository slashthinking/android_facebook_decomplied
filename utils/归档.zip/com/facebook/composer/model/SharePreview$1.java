package com.facebook.composer.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class SharePreview$1
  implements Parcelable.Creator<SharePreview>
{
  public SharePreview a(Parcel paramParcel)
  {
    return new SharePreview(paramParcel, null);
  }

  public SharePreview[] a(int paramInt)
  {
    return new SharePreview[paramInt];
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.model.SharePreview.1
 * JD-Core Version:    0.6.2
 */