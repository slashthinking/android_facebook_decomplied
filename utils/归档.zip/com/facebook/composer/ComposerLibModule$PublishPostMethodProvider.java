package com.facebook.composer;

import com.facebook.composer.protocol.PublishPostMethod;
import com.facebook.orca.inject.AbstractProvider;

class ComposerLibModule$PublishPostMethodProvider extends AbstractProvider<PublishPostMethod>
{
  private ComposerLibModule$PublishPostMethodProvider(ComposerLibModule paramComposerLibModule)
  {
  }

  public PublishPostMethod a()
  {
    return new PublishPostMethod();
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.ComposerLibModule.PublishPostMethodProvider
 * JD-Core Version:    0.6.2
 */