package com.facebook.composer.ui;

import com.facebook.orca.common.ui.titlebar.FbTitleBar.OnToolbarButtonListener;
import com.facebook.orca.common.ui.titlebar.TitleBarButtonSpec;

class ComposerSimpleActivity$1 extends FbTitleBar.OnToolbarButtonListener
{
  ComposerSimpleActivity$1(ComposerSimpleActivity paramComposerSimpleActivity)
  {
  }

  public void a(TitleBarButtonSpec paramTitleBarButtonSpec)
  {
    ComposerSimpleActivity.a(this.a);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.ui.ComposerSimpleActivity.1
 * JD-Core Version:    0.6.2
 */