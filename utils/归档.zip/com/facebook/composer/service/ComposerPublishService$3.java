package com.facebook.composer.service;

class ComposerPublishService$3
{
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.service.ComposerPublishService.3
 * JD-Core Version:    0.6.2
 */