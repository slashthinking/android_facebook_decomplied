package com.facebook.composer;

import com.facebook.composer.protocol.PublishLocationMethod;
import com.facebook.orca.inject.AbstractProvider;

class ComposerLibModule$PublishLocationMethodProvider extends AbstractProvider<PublishLocationMethod>
{
  private ComposerLibModule$PublishLocationMethodProvider(ComposerLibModule paramComposerLibModule)
  {
  }

  public PublishLocationMethod a()
  {
    return new PublishLocationMethod();
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.ComposerLibModule.PublishLocationMethodProvider
 * JD-Core Version:    0.6.2
 */