package com.facebook.composer;

import com.facebook.composer.protocol.SimplePhotoUploadMethod;
import com.facebook.orca.inject.AbstractProvider;

class ComposerLibModule$PagePhotoUploadMethodProvider extends AbstractProvider<SimplePhotoUploadMethod>
{
  private ComposerLibModule$PagePhotoUploadMethodProvider(ComposerLibModule paramComposerLibModule)
  {
  }

  public SimplePhotoUploadMethod a()
  {
    return new SimplePhotoUploadMethod();
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.ComposerLibModule.PagePhotoUploadMethodProvider
 * JD-Core Version:    0.6.2
 */