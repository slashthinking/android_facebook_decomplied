package com.facebook.composer.protocol;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class PublishLocationParams$1
  implements Parcelable.Creator<PublishLocationParams>
{
  public PublishLocationParams a(Parcel paramParcel)
  {
    return new PublishLocationParams(paramParcel);
  }

  public PublishLocationParams[] a(int paramInt)
  {
    return new PublishLocationParams[paramInt];
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.protocol.PublishLocationParams.1
 * JD-Core Version:    0.6.2
 */