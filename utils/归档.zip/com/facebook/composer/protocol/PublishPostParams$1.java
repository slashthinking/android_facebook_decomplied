package com.facebook.composer.protocol;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class PublishPostParams$1
  implements Parcelable.Creator<PublishPostParams>
{
  public PublishPostParams a(Parcel paramParcel)
  {
    return new PublishPostParams(paramParcel);
  }

  public PublishPostParams[] a(int paramInt)
  {
    return new PublishPostParams[paramInt];
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.protocol.PublishPostParams.1
 * JD-Core Version:    0.6.2
 */