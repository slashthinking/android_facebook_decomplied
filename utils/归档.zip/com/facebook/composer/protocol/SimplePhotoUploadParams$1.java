package com.facebook.composer.protocol;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class SimplePhotoUploadParams$1
  implements Parcelable.Creator<SimplePhotoUploadParams>
{
  public SimplePhotoUploadParams a(Parcel paramParcel)
  {
    return new SimplePhotoUploadParams(paramParcel);
  }

  public SimplePhotoUploadParams[] a(int paramInt)
  {
    return new SimplePhotoUploadParams[paramInt];
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.protocol.SimplePhotoUploadParams.1
 * JD-Core Version:    0.6.2
 */