package com.facebook.composer;

import com.facebook.composer.protocol.PublishCheckinMethod;
import com.facebook.orca.inject.AbstractProvider;

class ComposerLibModule$PublishCheckinMethodProvider extends AbstractProvider<PublishCheckinMethod>
{
  private ComposerLibModule$PublishCheckinMethodProvider(ComposerLibModule paramComposerLibModule)
  {
  }

  public PublishCheckinMethod a()
  {
    return new PublishCheckinMethod();
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.ComposerLibModule.PublishCheckinMethodProvider
 * JD-Core Version:    0.6.2
 */