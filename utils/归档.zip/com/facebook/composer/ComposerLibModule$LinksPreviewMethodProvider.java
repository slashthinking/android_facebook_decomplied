package com.facebook.composer;

import com.facebook.composer.protocol.LinksPreviewMethod;
import com.facebook.orca.inject.AbstractProvider;

class ComposerLibModule$LinksPreviewMethodProvider extends AbstractProvider<LinksPreviewMethod>
{
  private ComposerLibModule$LinksPreviewMethodProvider(ComposerLibModule paramComposerLibModule)
  {
  }

  public LinksPreviewMethod a()
  {
    return new LinksPreviewMethod();
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.composer.ComposerLibModule.LinksPreviewMethodProvider
 * JD-Core Version:    0.6.2
 */