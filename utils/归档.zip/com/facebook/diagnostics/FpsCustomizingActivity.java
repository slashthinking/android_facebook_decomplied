package com.facebook.diagnostics;

import com.google.common.collect.ImmutableSet;

public abstract interface FpsCustomizingActivity
{
  public abstract ImmutableSet<FpsEnableFlag> a(ImmutableSet<FpsEnableFlag> paramImmutableSet);
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.diagnostics.FpsCustomizingActivity
 * JD-Core Version:    0.6.2
 */