package com.facebook.debug;

class UiThreadWatchdog$6
  implements Runnable
{
  UiThreadWatchdog$6(UiThreadWatchdog paramUiThreadWatchdog)
  {
  }

  public void run()
  {
    UiThreadWatchdog.h(this.a);
    UiThreadWatchdog.i(this.a);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.debug.UiThreadWatchdog.6
 * JD-Core Version:    0.6.2
 */