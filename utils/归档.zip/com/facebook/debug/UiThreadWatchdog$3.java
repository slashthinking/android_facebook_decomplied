package com.facebook.debug;

class UiThreadWatchdog$3
  implements Runnable
{
  UiThreadWatchdog$3(UiThreadWatchdog paramUiThreadWatchdog)
  {
  }

  public void run()
  {
    UiThreadWatchdog.c(this.a);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.debug.UiThreadWatchdog.3
 * JD-Core Version:    0.6.2
 */