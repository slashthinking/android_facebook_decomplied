package com.facebook.common.util;

class DiskUsageUtil$1
  implements Runnable
{
  DiskUsageUtil$1(DiskUsageUtil paramDiskUsageUtil)
  {
  }

  public void run()
  {
    Toaster.a(DiskUsageUtil.a(this.a), 2131362203);
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.common.util.DiskUsageUtil.1
 * JD-Core Version:    0.6.2
 */