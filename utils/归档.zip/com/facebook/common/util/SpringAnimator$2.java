package com.facebook.common.util;

import com.google.common.collect.ImmutableList;
import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.Animator.AnimatorListener;
import java.util.ArrayList;
import java.util.Iterator;

class SpringAnimator$2
  implements Animator.AnimatorListener
{
  SpringAnimator$2(SpringAnimator paramSpringAnimator)
  {
  }

  public void a(Animator paramAnimator)
  {
    ArrayList localArrayList = this.a.k();
    if (localArrayList == null);
    while (true)
    {
      return;
      Iterator localIterator = ImmutableList.a(localArrayList).iterator();
      while (localIterator.hasNext())
        ((Animator.AnimatorListener)localIterator.next()).a(this.a);
    }
  }

  public void b(Animator paramAnimator)
  {
    ArrayList localArrayList = this.a.k();
    if (localArrayList == null);
    while (true)
    {
      return;
      Iterator localIterator = ImmutableList.a(localArrayList).iterator();
      while (localIterator.hasNext())
        ((Animator.AnimatorListener)localIterator.next()).b(this.a);
    }
  }

  public void c(Animator paramAnimator)
  {
    ArrayList localArrayList = this.a.k();
    if (localArrayList == null);
    while (true)
    {
      return;
      Iterator localIterator = ImmutableList.a(localArrayList).iterator();
      while (localIterator.hasNext())
        ((Animator.AnimatorListener)localIterator.next()).c(this.a);
    }
  }

  public void d(Animator paramAnimator)
  {
    ArrayList localArrayList = this.a.k();
    if (localArrayList == null);
    while (true)
    {
      return;
      Iterator localIterator = ImmutableList.a(localArrayList).iterator();
      while (localIterator.hasNext())
        ((Animator.AnimatorListener)localIterator.next()).d(this.a);
    }
  }
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.common.util.SpringAnimator.2
 * JD-Core Version:    0.6.2
 */