package com.facebook.common.util.event;

public abstract class FbEventSubscriber<T extends FbEvent>
{
  public abstract Class<T> a();

  public abstract void a(T paramT);
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.common.util.event.FbEventSubscriber
 * JD-Core Version:    0.6.2
 */