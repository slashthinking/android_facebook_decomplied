package com.facebook.common.util.event;

public abstract interface FbEvent
{
}

/* Location:           /data1/software/apk2java/dex2jar-0.0.9.12/secondary-1.dex_dex2jar.jar
 * Qualified Name:     com.facebook.common.util.event.FbEvent
 * JD-Core Version:    0.6.2
 */